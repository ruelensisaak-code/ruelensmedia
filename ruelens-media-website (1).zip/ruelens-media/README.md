# Ruelens Media website

Een snelle, statische portfolio-website gebouwd met Astro.

## Vereisten
- Node.js (LTS)
- Een GitHub-account (voor automatische publicatie)
- Een Cloudflare-account

## Lokaal bekijken
1. Pak de ZIP uit.
2. Open deze map in een terminal of editor.
3. Voer uit:
   ```bash
   npm install
   npm run dev
   ```
4. Open de lokale URL die Astro toont.

## Productiebuild testen
```bash
npm run build
npm run preview
```
De gebouwde website komt in `dist/`.

## Foto's toevoegen
1. Plaats geoptimaliseerde JPG/WebP-afbeeldingen in `public/images/`.
2. Open `src/data/portfolio.js`.
3. Voeg een object toe aan de lijst, met `src`, `alt`, `category` en `title`.
4. Gebruik alleen foto's die je zelf mag publiceren.

De homepage-hero staat ingesteld op `/images/hero-football.jpg`. Als je deze foto nog niet hebt, vervang de waarde `heroImage` in `src/pages/index.astro` door het pad naar een eigen foto. Er zit een visuele CSS-fallback in, maar je eigen foto maakt het resultaat veel sterker.

## Contactformulier
Het formulier is momenteel een voorbereid aanvraagformulier dat via de e-mailapp van de bezoeker kan worden verstuurd. Vervang `contact@ruelensmedia.be` in `src/pages/contact.astro` door je echte e-mailadres voordat je publiceert. Als je later server-side verwerking wilt, kun je een formulierdienst of Cloudflare Worker toevoegen.

## Prijzen
De prijzen staan in `src/data/services.js`. Pas ze aan als je tarieven wijzigen.

## Publiceren met Cloudflare Pages
1. Maak een GitHub-repository en upload alle bestanden uit deze map.
2. Open Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git.
3. Selecteer de repository.
4. Build command: `npm run build`
5. Build output directory: `dist`
6. Deploy.
7. Test eerst de `*.pages.dev`-URL.
8. Voeg pas daarna `ruelensmedia.be` toe via Custom domains en volg de DNS-instructies van Cloudflare.

Controleer de DNS-records vóór je nameservers wijzigt, vooral als je e-mail op je domein gebruikt.
