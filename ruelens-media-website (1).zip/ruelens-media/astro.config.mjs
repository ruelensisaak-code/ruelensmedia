import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://ruelensmedia.be',
  output: 'static'
});
