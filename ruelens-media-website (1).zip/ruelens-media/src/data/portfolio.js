// Vervang de voorbeelditems door je eigen foto's in public/images/.
// Categories: "voetbal", "spelers", "events"
export const portfolio = [
  {
    src: "/images/portfolio-01.jpg",
    alt: "Voetbalactie tijdens een wedstrijd",
    title: "Wedstrijdmoment",
    category: "voetbal"
  },
  {
    src: "/images/portfolio-02.jpg",
    alt: "Speler in actie op het voetbalveld",
    title: "In volle actie",
    category: "spelers"
  },
  {
    src: "/images/portfolio-03.jpg",
    alt: "Sfeerbeeld langs het voetbalveld",
    title: "Langs de lijn",
    category: "voetbal"
  },
  {
    src: "/images/portfolio-04.jpg",
    alt: "Emotie na een beslissend moment",
    title: "Pure emotie",
    category: "voetbal"
  },
  {
    src: "/images/portfolio-05.jpg",
    alt: "Portret van een sporter",
    title: "Speler in beeld",
    category: "spelers"
  },
  {
    src: "/images/portfolio-06.jpg",
    alt: "Sfeer tijdens een evenement",
    title: "Eventreportage",
    category: "events"
  }
];
