export const services = [
  {
    title: "Club Matchday",
    description: "Een fotoreportage van de wedstrijd, met actie, emotie, supporters en de sfeer rond het veld. Voor communicatiekanalen en clubarchief.",
    packages: [
      { count: "50 afgewerkte foto's", price: "€100" },
      { count: "100 afgewerkte foto's", price: "€150" }
    ]
  },
  {
    title: "Speler in de Spotlights",
    description: "Een reportage waarin één speler centraal staat, met sterke wedstrijdbeelden en momenten om te delen.",
    packages: [
      { count: "50 afgewerkte foto's", price: "€75" },
      { count: "100 afgewerkte foto's", price: "€125" }
    ]
  },
  {
    title: "Eventfotografie",
    description: "Een reportage die de sfeer, mensen en belangrijkste momenten van jouw evenement vastlegt. Prijs op aanvraag."
  },
  {
    title: "Sport- en clubfotografie",
    description: "Fotografie op maat voor clubs, sportorganisaties, websites en sociale media. Bespreek de opdracht en gewenste beelden."
  }
];
